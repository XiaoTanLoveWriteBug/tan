package com.tan.webstore.config;


import com.tan.webstore.interceptor.LoginInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.ArrayList;
import java.util.List;
@Configuration
//处理器拦截器注册的功能
public class LoginInterceptorConfig000000 implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        HandlerInterceptor handlerInterceptor=new LoginInterceptor();



        //定义白名单
        List<String> addpatters=new ArrayList<String>();
        addpatters.add("/bootstrap3/**");
        addpatters.add("/css/**");
        addpatters.add("/images/**");
        addpatters.add("/js/**");


        addpatters.add("/web/login.html");
        addpatters.add("/web/register.html");
        addpatters.add("/web/index.html");
        addpatters.add("/web/product.html");
        addpatters.add("/reg");
        addpatters.add("/login");
        addpatters.add("/District/**");
        addpatters.add("/products/**");

        //        配置拦截路径，配置百名单(css文件等别过滤)，黑名单
        registry.addInterceptor(handlerInterceptor).addPathPatterns("/**").
        excludePathPatterns(addpatters);//白名单通行

    }
}
