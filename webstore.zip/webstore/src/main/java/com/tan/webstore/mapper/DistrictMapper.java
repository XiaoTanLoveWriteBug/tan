package com.tan.webstore.mapper;


import com.tan.webstore.POJO.District;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.List;

@Component
public interface DistrictMapper {
    //查询父区域
    List<District> findByParent(String parent);

//查名字
    String findNameByCode(String code);
}
