package com.tan.webstore.controller;
//控制层基类

import com.sun.corba.se.impl.protocol.AddressingDispositionException;
import com.tan.webstore.controller.Exception.*;
import com.tan.webstore.service.ex.*;
import com.tan.webstore.until.JsonUntil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpSession;
@Controller
public class BaseController {
//捕获异常处理
    public  static  final  int Ok=99;
  @ExceptionHandler({ServiceException.class,FileUploadException.class})//srpingboot自带的，用于同意处理异常?,增加异常处理父类
//    判断异常类型
  public JsonUntil<Void> SwitchExceptionUserRig(Throwable e)
  {
      JsonUntil<Void> result=new JsonUntil<>(e);
      if (e instanceof InsertException){
        result.setState(97);
          result.setMessage("插入时产生未知异常");

  }
      else if (e instanceof UsernameDuplicatetedException){
      result.setState(98);
          result.setMessage("账户名被注册");
      }

      else if (e instanceof UserNotFoundException){
          result.setState(1000);
          result.setMessage("用户数据不存在");
      }
      else if (e instanceof PasswordNotMatchException){
          result.setState(1100);
          result.setMessage("用户名的密码错误");
      }



      //修改密码得异常
      else if (e instanceof PasswordNotMatchException){
          result.setState(2000);
          result.setMessage("修改密码异常");
      }
//修改头像所产生式的自定义各类异常
      else if (e instanceof FileEmptyException) {
          result.setState(6000);
          result.setMessage("上传文件为空");
      } else if (e instanceof FileSizeException) {
          result.setState(6001);
          result.setMessage("上传的文件的大小超出了限制值");
      } else if (e instanceof FileTypeException) {
          result.setState(6002);
          result.setMessage(" 上传的文件类型超出了限制");
      } else if (e instanceof FileStateException) {
          result.setState(6003);
          result.setMessage("上传的文件状态异常");
      } else if (e instanceof FileUploadIOException) {
          result.setState(6004);
          result.setMessage("文件上传相关异常的基类");

          //插入地址所造成的异常
      }
      else if (e instanceof FileUploadIOException) {
          result.setState(6005);
          result.setMessage("上传文件时读写异常");

          //插入地址所造成的异常
      }



      else if (e instanceof AddressCountLimitException) {
          result.setState(6006);
          result.setMessage("用户收获地址超出最大地址数量");
      }else if (e instanceof AddressNotFoundException) {
          result.setState(6007);
          result.setMessage("未找到用户地址");
      }else if (e instanceof AddressingDispositionException) {
          result.setState(6008);
          result.setMessage("非法访问的异常");
      }else if (e instanceof DeleteException) {
          result.setState(6009);
          result.setMessage("删除数据的异常");
      }else if (e instanceof ProductNotFoundException) {
          result.setState(6010);
          result.setMessage("产品未找到");
      }else if (e instanceof CartNotFountException) {
          result.setState(6011);
          result.setMessage("未找到购物车信息");
      }

  return result;
  }






//session的设置，在父类封装，这里我们头像不考率，我们封装在cooking中
//session能保存任何数据类型，而cooking只能保存string类型
    protected final Integer getuidFromSession(HttpSession session)
    {
       return   Integer.valueOf(session.getAttribute("uid").toString()) ;

    }
protected final String getUsernameFromSession(HttpSession session)
{
   return session.getAttribute("username").toString();
}

}