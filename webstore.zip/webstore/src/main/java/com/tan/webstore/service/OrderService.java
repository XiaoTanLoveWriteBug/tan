package com.tan.webstore.service;

import com.tan.webstore.POJO.Order;

public interface OrderService {
    Order AddOerder(Integer aid, Integer uid, String username, Integer[] cids);
}
