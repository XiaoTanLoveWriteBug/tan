package com.tan.webstore.controller;

import com.tan.webstore.POJO.Product;
import com.tan.webstore.service.impl.ProductServiceImpl;
import com.tan.webstore.until.JsonUntil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("products")
public class ProductController extends BaseController {
    @Autowired
    private ProductServiceImpl productService;

    @RequestMapping("hot_list")
    public JsonUntil<List<Product>> getHotList() {
        List<Product> data = productService.findHotList();
        return new JsonUntil<>(Ok, data);
    }

    @GetMapping("{id}/details")
    public JsonUntil<Product> getById(@PathVariable("id") Integer id) {
        // 调用业务对象执行获取数据
        Product data = productService.findById(id);
        // 返回成功和数据
        return new JsonUntil<Product>(Ok, data);
    }
}
