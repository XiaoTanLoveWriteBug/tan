package com.tan.webstore.service.impl;

import com.tan.webstore.POJO.Address;
import com.tan.webstore.POJO.Order;
import com.tan.webstore.POJO.OrderItem;

import com.tan.webstore.mapper.OrderMapper;
import com.tan.webstore.service.OrderService;
import com.tan.webstore.service.ex.InsertException;
import com.tan.webstore.vo.CartVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
 @Autowired
    private OrderMapper orderMapper;
 @Autowired
 private AdressServiceImpl adressService;
 @Autowired
 private CarServiceIml carServiceIml;
 @Override
    public Order AddOerder(Integer aid, Integer uid, String username, Integer[] cids) {
     //查询选择购物车数据
     List<CartVO> cars=carServiceIml.getVOByCids(uid,cids);
     //计算总价
     long TOTALPrice=0;
     for (CartVO c: cars)
     {
         TOTALPrice=TOTALPrice+ c.getRealPrice() * c.getNum();
     }
//创建订单数据


     Order order=new Order();
     Date now=new Date();
     order.setUid(uid);
    //补全地址信息
     Address address=adressService.getByAid(aid,uid);
//     电话，名字。城市，地区，省份
     order.setRecvPhone(address.getPhone());
     order.setRecvName(address.getName());
     order.setRecvCity(address.getCityName());
     order.setRecvArea(address.getAreaName());
     order.setRecvProvince(address.getProvinceName());
     order.setRecvAddress(address.getAddress());

     // 补全数据：status
     order.setStatus(0);
//下单时间
     order.setOrderTime(now);

//     补全价格
     order.setTotalPrice(TOTALPrice);


//     补全日志
     order.setModifiedTime(now);
     order.setCreatedUser(username);
     order.setCreatedTime(now);
     order.setModifiedUser(username);
//插入订单数据
Integer row=orderMapper.AddOrder(order);



if (row!=1)
 {
  throw new InsertException("插入订单数据失败，请联系管理员");
 }

/**
 * 可能出错的地方
 */
     int selectoid=orderMapper.selectoid(order);








//插入订单子项目
     for (CartVO cart : cars) {
         // 创建订单商品数据
         OrderItem item = new OrderItem();
         // 补全数据：setOid(order.getOid())
         item.setOid(selectoid);
         // 补全数据：pid, title, image, price, num
         item.setPid(cart.getPid());
         item.setTitle(cart.getTitle());
         item.setImage(cart.getImage());
         item.setPrice(cart.getRealPrice());
         item.setNum(cart.getNum());
         // 补全数据：4项日志
         item.setCreatedUser(username);
         item.setCreatedTime(now);
         item.setModifiedUser(username);
         item.setModifiedTime(now);
         // 插入订单商品数据
         Integer rows2 = orderMapper.AddOrderItem(item);
         if (rows2 != 1) {
             throw new InsertException("插入订单商品数据时出现未知错误，请联系系统管理员");
         }
     }

     return order;
    }
}
