package com.tan.webstore.service.ex;
//自定义用户名被占用的异常
public class UsernameDuplicatetedException  extends  ServiceException{
    public UsernameDuplicatetedException() {
        super();
    }

    public UsernameDuplicatetedException(String message) {
        super(message);
    }

    public UsernameDuplicatetedException(String message, Throwable cause) {
        super(message, cause);
    }

    public UsernameDuplicatetedException(Throwable cause) {
        super(cause);
    }

    protected UsernameDuplicatetedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
