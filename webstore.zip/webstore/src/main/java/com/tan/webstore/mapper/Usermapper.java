package com.tan.webstore.mapper;


import com.tan.webstore.POJO.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import javax.print.DocFlavor;
import java.util.Date;

@Repository
public interface Usermapper {
//    判断返回值是否执行成功
    Integer addUser(User user);
//    查询用户名是否存在，找到返回数据，没有找到返回Null值
User byUsername(String username);
//记录修改时间，记录修改人
Integer UpdatePassword(Integer uid, String password, String modifiedUser, Date modifiedTime);
//id查询用户数据
    User findByUid(Integer uid);

    Integer updateInforByuid(User user);
//更新头像  @Param("SQL数据库的参数名") 与外部参数名起等价 用来解决参数不一致的问题
    Integer updateavatarByuid(@Param("uid") Integer uid,
                              @Param("avatar")String avatar,
                              @Param("modified_user")String modifiedUser,
                              @Param("modified_time")Date modifiedTime
    );

}
