package com.tan.webstore.service;

import com.tan.webstore.POJO.District;

import java.util.List;

public interface IDistrictService {

    List<District> getByParent(String parent);


    String findNameByCode(String code);

}
