package com.tan.webstore.controller;

import com.sun.org.apache.xml.internal.resolver.helpers.PublicId;
import com.tan.webstore.service.impl.CarServiceIml;
import com.tan.webstore.until.JsonUntil;
import com.tan.webstore.vo.CartVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.w3c.dom.ls.LSInput;

import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
public class CartContorller extends BaseController{
    @Autowired
    CarServiceIml carServiceIml;



@RequestMapping("/add_to_cart")
    public JsonUntil<Void> addTocart(Integer pid, Integer amount, HttpSession session)
{

carServiceIml.addtoCart(getuidFromSession(session),pid,amount,getUsernameFromSession(session));

return new JsonUntil<>(Ok);
}
@RequestMapping("/getVOByUid")
    public JsonUntil<List<CartVO>> getVOByUid(HttpSession session)
{
    List<CartVO> data=
    carServiceIml.getVOByid(getuidFromSession(session));
    return new  JsonUntil<>(Ok,data);
}
    @RequestMapping("/{cid}/addnum")
    public JsonUntil<Integer> addnum(@PathVariable("cid") Integer cid, HttpSession session)
    {
        Integer data=
                carServiceIml.addnum(cid,getuidFromSession(session),getUsernameFromSession(session));
        return new  JsonUntil<>(Ok,data);
    }

    @RequestMapping("/list")
    public JsonUntil<List<CartVO>> getVOByCids(Integer[] cids,HttpSession session)
    {
List<CartVO> data=carServiceIml.getVOByCids(getuidFromSession(session),cids);
return new JsonUntil<>(Ok,data);

    }


}
