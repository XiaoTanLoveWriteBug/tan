package com.tan.webstore.mapper;

import com.tan.webstore.POJO.Product;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public interface ProductMapper {
    //查询热销商品的前四名

    List<Product> findHotList();


    //根据商品id查询商品详情
    Product findById(Integer id);



}
