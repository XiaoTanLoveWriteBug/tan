package com.tan.webstore.controller;

import com.sun.xml.internal.ws.api.pipe.ContentType;
import com.tan.webstore.POJO.User;
import com.tan.webstore.controller.Exception.*;
import com.tan.webstore.service.IUserService;
import com.tan.webstore.service.ex.InsertException;
import com.tan.webstore.service.ex.ServiceException;
import com.tan.webstore.service.impl.UserServiceImpl;
import com.tan.webstore.until.JsonUntil;
import org.apache.ibatis.annotations.Param;
import org.omg.CORBA.INTERNAL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@RestController
public class UserContorller extends BaseController{
  @Autowired
    private UserServiceImpl Isim;


  @PostMapping("/reg")
    public JsonUntil<Void> reg(User user){

        Isim.reg(user);

        return new JsonUntil<>(Ok);

    }

//  以下代码已被优化，放在了BaseController中的
//  @PostMapping("/reg")
////用状态码来响应是否注册成功
//    public JsonUntil<Void> reg(User user)
//
//  {   JsonUntil<Void> result=new JsonUntil<>();
//      try {
//          Isim.reg(user);
//      result.setState(99);
//      result.setMessage("用户注册成功");
//      return result;
//  } catch (InsertException e){
//      result.setState(98);
//      result.setMessage("插入时产生未知异常");
//  } catch(ServiceException e)
//      {
//          result.setState(97);
//          result.setMessage("账户名被注册");
//      }
//  return  result;
//
//  }

//编写处理登录请求
@RequestMapping("/login")
    public JsonUntil<User> login(String username, String PASSWORD, HttpSession session)
    {
User data =Isim.login(username,PASSWORD);
//注意，session为全局变量，都可使用
session.setAttribute("username",data.getUsername());
session.setAttribute("uid",data.getUid());
//        System.out.println(getuidFromSession(session));
//        System.out.println(getUsernameFromSession(session));
   return new JsonUntil<User>(Ok,data);


    }


//    修改密码
    @RequestMapping("/ChangePassword")
        public JsonUntil<Void> UpDatePassword(String OldPassword,String NewPassword,HttpSession session)
    {
        int uid=getuidFromSession(session);
        String username=getUsernameFromSession(session);
Isim.UpdatePassword(uid,username,OldPassword,NewPassword);
return  new JsonUntil<>(Ok);
    }
    //得到数据信息
@RequestMapping("/getbyid")
    public JsonUntil<User> getbyuid(HttpSession session)
{
User data=Isim.getByUid(getuidFromSession(session));
return new JsonUntil<>(Ok,data);
}


    @RequestMapping("/changinfo")
    public JsonUntil<Void> changinfo(HttpSession session,User user)
    {
Integer uid=getuidFromSession(session);
String username=getUsernameFromSession(session);
Isim.changinfo(user,username,uid);
return new JsonUntil<>(Ok);
    }


    //定义上传的最大值文件
    public static final Integer AVATAR_MAX_SIZE=10*1024*1024;//springboot判断用的字节，所以这里用这种方式

//  定义上传文件类型
    public static final List<String> AVATAR_type=new ArrayList<>();
    static {
        AVATAR_type.add("image/jpeg");
        AVATAR_type.add("image/png");
        AVATAR_type.add("image/bmp");
        AVATAR_type.add("image/gif");

    }

  @RequestMapping("/UpdateAvatar")
    public JsonUntil<String> updateavatar(HttpSession session, MultipartFile file)
    /*MultipartFile是springing提供的任何类型的文件，
    这里又因为springboot整合了springmvc，
    所以这里需要声明这个file这个名称，假如和前端参数不一致，
    可以使用Requestparm（）
            */
    {
if (file.isEmpty()){
    throw new FileSizeException("文件为空");
}
if (file.getSize()>AVATAR_MAX_SIZE)
    {
        throw new FileSizeException("文件超出大小限制");
    }
    //判断文件类型
       String contentType = file.getContentType();
        if(!AVATAR_type.contains(contentType)){

throw  new FileTypeException("文件类型错误");
    }
//获取当前文件路劲，session可以，还有其他api可以实现
        String parent=
                session.getServletContext().getRealPath("upload");
        File dir=new File(parent);
        if (!dir.exists())
        {
            dir.mkdirs();//创建当前目录
        }
        //拼接前后缀，前缀名称直接使用uuid随机生成
        String suffix="";
        //获取文件名
        String Originalfilename=file.getOriginalFilename();
        int beginIndex=Originalfilename.lastIndexOf(".");//得到.的未知
        if (beginIndex>0)
        {
            suffix=Originalfilename.substring(beginIndex);
        }
        //生成前面部分
        String filename= UUID.randomUUID().toString()+suffix;

        File dest=new File(dir,filename);
        try {
            file.transferTo(dest);//转移文件
        } catch (IOException e) {
            throw new FileUploadIOException("上传文件时读写错误，请稍后重新尝试");
        }catch (IllegalStateException e) {
            throw new FileStateException("文件状态异常，可能文件已被移动或删除");
        }
//执行方法
        // 头像路径
        String avatar = "/upload/" + filename;
        // 从Session中获取uid和username
        Integer uid = getuidFromSession(session);
        String username = getUsernameFromSession(session);

        Isim.updateavatar(uid,avatar,username);
        return new JsonUntil<>(Ok,avatar);




    }





}

