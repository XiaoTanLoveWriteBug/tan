package com.tan.webstore.service.impl;

import com.tan.webstore.POJO.User;
import com.tan.webstore.mapper.Usermapper;
import com.tan.webstore.service.IUserService;
import com.tan.webstore.service.ex.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import org.yaml.snakeyaml.events.Event;

import javax.print.DocFlavor;
import javax.xml.crypto.Data;
import java.rmi.server.UID;
import java.util.Date;
import java.util.UUID;

@Service
public class UserServiceImpl implements IUserService {
   @Autowired
    Usermapper mapper;

    @Override
    public void reg(User user) {
//判断用户名是否被注册，被注册抛出自定义异常，没有则
//
     User res= mapper.byUsername(user.getUsername());
    if(res!=null)
    {
        throw new UsernameDuplicatetedException("username被占用");
    }


//设置盐值
        String salt= UUID.randomUUID().toString().toUpperCase();

        user.setSalt(salt);

        String saltPASSWORD=getMD5PASSWORD(user.getPASSWORD(),salt);
        //       String saltPASSWORD=getMD5PASSWORD(PASSWORD,salt);



        Date data=new Date();
        user.setPASSWORD(saltPASSWORD);
        user.setCreatedTime(data);
        user.setModifiedTime(data);
        user.setIsDelete(0);
        user.setCreatedUser(user.getUsername());
        user.setModifiedUser(user.getUsername());
        System.out.println(saltPASSWORD);
        System.out.println(user.getPASSWORD());

        //    假想在插入时突然断电造成异常，咱们也抛出，这里返回的是adduser的结果集了
//    这里补充我们没写的数据
        Integer insert=mapper.addUser(user);
    if (insert!=1)
    {
        throw new InsertException("在注册过程中产生位置异常");
    }
    }


    public String getMD5PASSWORD(String password,String salt) {
    for (int i = 0; i < 3; i++) {
//MD5加密算法处理(三次)
   password=DigestUtils.md5DigestAsHex((salt + password + salt).getBytes()).toUpperCase();
    }
    return password;
}
    @Override
    public User login(String username, String PASSWORD) {
//        判断数据：
User rel=mapper.byUsername(username);



        if(rel==null)
{
    throw  new UserNotFoundException("用户不存在");
}
//判断密码，要先获取盐值，用MD5算法来判断

String MD5password=getMD5PASSWORD(PASSWORD,rel.getSalt());


        if (!rel.getPASSWORD().equals(MD5password))
{
    throw new PasswordNotMatchException("账户密码错误");
}
//判断is_delete是否被删除
        if (rel.getIsDelete()==1)
        {
            throw  new UserNotFoundException("用户被注销");
        }
//        辅助其他页面开发，封装我们需要的数据



        User user=new User();
        user.setUid(rel.getUid());
        user.setUsername(rel.getUsername());
        user.setAvatar(rel.getAvatar());
        return  user;
   }


    @Override
    public void UpdatePassword(int uid, String username, String OldPassword, String NewPassword) {
  User user=mapper.findByUid(uid);
if (user==null)
{
    throw  new UserNotFoundException("用户id不存在");
}
//密码比较，算法加密

        String saltpassword=getMD5PASSWORD(OldPassword,user.getSalt());


         if(!user.getPASSWORD().equals(saltpassword))
         {
             throw new PasswordNotMatchException("你的密码错误");
         }
         String NewMd5Password=getMD5PASSWORD(NewPassword,user.getSalt());

         Integer rows=mapper.UpdatePassword(uid,NewMd5Password,username,new Date());

if (rows!=1){
    throw new UpdateException("插入产生未知的异常");
}

    }

    @Override
    public User getByUid(Integer uid) {
        User ruselt=mapper.findByUid(uid);
        if (ruselt==null||ruselt.getIsDelete()==1)
        {
            throw  new UserNotFoundException("用户数据不存在");
        }
        User user=new User();
        user.setUsername(ruselt.getUsername());
        user.setEmail(ruselt.getEmail());
        user.setPhone(ruselt.getPhone());
        user.setGender(ruselt.getGender());
        return user;


    }
//修改信息
    @Override
    public void changinfo(User user, String username, Integer uid) {
 User result= mapper.findByUid(uid);
    if (result==null)
    {
        throw  new UserNotFoundException("用户数据不存在");
    }
    user.setUid(uid);
    user.setUsername(username);
    user.setModifiedTime(new Date());
    Integer rows= mapper.updateInforByuid(user);
    if (rows!=1)
    {
        throw new UpdateException("更新数据时产产生异常");
    }
    }


    //修改头像
    @Override
    public void updateavatar(Integer uid, String avatar, String username) {
        User result=mapper.findByUid(uid);
        if (result==null||result.getIsDelete().equals(1))
        {
            throw new UserNotFoundException("用户数据不存在");
        }
        Integer rows=mapper.updateavatarByuid(uid,avatar,username,new Date());
if (rows!=1)
{
    throw new UpdateException("更新用户产生的异常");
}
    }





}
