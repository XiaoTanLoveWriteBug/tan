package com.tan.webstore.service.impl;

import com.tan.webstore.POJO.Cart;
import com.tan.webstore.POJO.Product;
import com.tan.webstore.mapper.CartMapper;
import com.tan.webstore.mapper.ProductMapper;
import com.tan.webstore.service.ICarService;
import com.tan.webstore.service.ex.AccessDeniedException;
import com.tan.webstore.service.ex.CartNotFountException;
import com.tan.webstore.service.ex.InsertException;
import com.tan.webstore.service.ex.UpdateException;
import com.tan.webstore.vo.CartVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.ls.LSInput;
import sun.security.provider.certpath.CertId;

import java.time.chrono.IsoChronology;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@Service
public class CarServiceIml implements ICarService {
    @Autowired
    CartMapper cartMapper;

    //购物车业务依赖于商品的持久层，从这里来，减少效率并且减少流量开发
    @Autowired
    ProductMapper productMapper;
//更新数量
    @Override
    public void addtoCart(Integer uid, Integer pid, Integer amount, String username) {
//查询但钱商品是否存在
        Cart result=cartMapper.findByUidAndPid(uid,pid);
        if (result==null)//没有加入过
        {
            //补全购物车数据
            Cart cart=new Cart();
            cart.setUid(uid);
            cart.setPid(pid);
            cart.setNum(amount);
//商品表取的价格
            Product product= productMapper.findById(pid);

            cart.setPrice(product.getPrice());


            //补全日志
            cart.setCreatedTime(new Date());
            cart.setCreatedUser(username);
            cart.setModifiedUser(username);
            cart.setModifiedTime(new Date());

//判断结果




            Integer rows=cartMapper.insert(cart);
            if (rows!=1)
            {
                throw  new InsertException("插入数据时产生未知的异常");
            }
        }
        else {
Integer num=result.getNum()+amount;
     Integer rows= cartMapper.updateNumByCid(result.getCid(),num,username,new Date());

if (rows!=1)
{
    throw new UpdateException("更新数据时产生未知的异常");
}

        }
    }

    @Override
    public List<CartVO> getVOByid(Integer uid) {
        return cartMapper.findVOByUid(uid);
    }

    @Override
    public Integer addnum(Integer cid, Integer uid, String username) {
        // 调用findByCid(cid)根据参数cid查询购物车数据
        Cart result = cartMapper.findByCid(cid);
        // 判断查询结果是否为null
        if (result == null) {
            // 是：抛出CartNotFoundException
            throw new CartNotFountException("尝试访问的购物车数据不存在");
        }

        // 判断查询结果中的uid与参数uid是否不一致
        if (!result.getUid().equals(uid)) {
            // 是：抛出AccessDeniedException
            throw new AccessDeniedException("非法访问");
        }

        // 可选：检查商品的数量是否大于多少(适用于增加数量)或小于多少(适用于减少数量)
        // 根据查询结果中的原数量增加1得到新的数量num
        Integer num = result.getNum() + 1;

        // 创建当前时间对象，作为modifiedTime
        Date now = new Date();
        // 调用updateNumByCid(cid, num, modifiedUser, modifiedTime)执行修改数量
        Integer rows = cartMapper.updateNumByCid(cid, num, username, now);
        if (rows != 1) {
            throw new InsertException("修改商品数量时出现未知错误，请联系系统管理员");
        }
        // 返回新的数量
        return num;
    }

    @Override
    public List<CartVO> getVOByCids(Integer uid, Integer[] cids) {
        List<CartVO> list = cartMapper.findVOByCids(cids);
        Iterator<CartVO> it = list.iterator();
        //判断是否属于自己的购物车
        while (it.hasNext()) {
            CartVO cartVO = it.next();
            if (!cartVO.getUid().equals(uid)) {
                it.remove();
            }
        }
return list;
    }
}

