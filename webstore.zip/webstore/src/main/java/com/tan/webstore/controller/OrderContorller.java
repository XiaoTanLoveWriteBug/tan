package com.tan.webstore.controller;

import com.tan.webstore.POJO.Order;
import com.tan.webstore.service.OrderService;
import com.tan.webstore.service.impl.OrderServiceImpl;
import com.tan.webstore.until.JsonUntil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

@RestController
public class OrderContorller extends BaseController{
@Autowired
OrderServiceImpl orderService;
@PostMapping("/addorder")
private JsonUntil<Order> addorder(Integer aid, Integer[] cids, HttpSession session)
{
    Integer uid=getuidFromSession(session);
    String username=getUsernameFromSession(session);
 Order data= orderService.AddOerder(aid,uid,username,cids);
return new JsonUntil<>(Ok,data);
}

}
