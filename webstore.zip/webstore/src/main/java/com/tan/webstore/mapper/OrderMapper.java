package com.tan.webstore.mapper;

import com.tan.webstore.POJO.Order;
import com.tan.webstore.POJO.OrderItem;

public interface OrderMapper {

    Integer AddOrder(Order order);
    Integer AddOrderItem(OrderItem orderItem);
    Integer selectoid(Order order);
}
