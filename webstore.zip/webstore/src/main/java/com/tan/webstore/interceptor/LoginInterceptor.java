package com.tan.webstore.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.handler.Handler;

//登录拦截器,
//检测sessionz中是否有UID数据，如果有则放行，没有则重定向

public class LoginInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
  if (request.getSession().getAttribute("uid") == null)
     {
    response.sendRedirect("/web/login.html");

    return false;
      }
        return true;
    }



}
