package com.tan.webstore.service;

import com.tan.webstore.POJO.Product;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface IProductService {
//热销产品集合
    List<Product> findHotList();



    //根据商品id查询商品详情
    Product findById(Integer id);


}
