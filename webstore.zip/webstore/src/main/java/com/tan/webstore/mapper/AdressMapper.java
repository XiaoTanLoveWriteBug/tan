package com.tan.webstore.mapper;

import com.tan.webstore.POJO.Address;
import com.tan.webstore.POJO.District;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;


@Repository
//收获地址
public interface AdressMapper {
//插入操作
    Integer insertAdress(Address address);

//统计行数
    Integer countByUid(Integer uid);


//根据Id查询地址
List<Address> FindAdressByUID(Integer uid);



    Integer updateNonDefaultByUid(Integer uid);

    //将指定的收货地址设置为默认地址

    Integer updateDefaultByAid(Integer aid, String modifiedUser, Date modifiedTime);

    // 根据收货地址aid值，查询收货地址详情

    Address findByAid(Integer aid);

    //根据收货地址id删除数据

    Integer deleteByAid(Integer aid);

    // 查询某用户最后修改的收货地址

    Address findLastModified(Integer uid);

}
