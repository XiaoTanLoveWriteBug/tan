package com.tan.webstore.service;

import com.tan.webstore.vo.CartVO;

import java.util.List;

public interface ICarService {
    //商品添加到购物车

    void addtoCart(Integer uid,Integer pid,Integer amount,String username);

    List<CartVO> getVOByid(Integer uid);

    Integer addnum(Integer cid,Integer uid,String username);


    List<CartVO> getVOByCids(Integer uid, Integer[] cids);
}
