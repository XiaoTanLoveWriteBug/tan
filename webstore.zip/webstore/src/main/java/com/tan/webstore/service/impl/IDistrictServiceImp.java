package com.tan.webstore.service.impl;

import com.tan.webstore.POJO.District;
import com.tan.webstore.mapper.DistrictMapper;
import com.tan.webstore.service.IDistrictService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IDistrictServiceImp implements IDistrictService {
    @Autowired
    private DistrictMapper districtMapper;

    @Override
    public List<District> getByParent(String parent) {
        //在进行网络数据传输时，可以将尽量避免无效数据，将无效数据设置为null


        List<District> list= districtMapper.findByParent(parent);
    for(District d:list)
    {
d.setId(null);
d.setParent(null);
    }
    return list;
    }

    @Override
    public String findNameByCode(String code) {
        return districtMapper.findNameByCode(code);
    }
}
