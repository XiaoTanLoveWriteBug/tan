package com.tan.webstore.controller;

import com.tan.webstore.POJO.District;
import com.tan.webstore.service.impl.IDistrictServiceImp;
import com.tan.webstore.until.JsonUntil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("District")
public class DistrictContorller extends BaseController{
     @Autowired
    private IDistrictServiceImp iDistrictServiceImp;

@RequestMapping({"/",""})
    public JsonUntil<List<District>> getByParent(String parent)
{
List<District> list=iDistrictServiceImp.getByParent(parent);
return new  JsonUntil<>(Ok,list);
}

}
