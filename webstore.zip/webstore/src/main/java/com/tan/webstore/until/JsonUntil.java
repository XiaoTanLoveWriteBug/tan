package com.tan.webstore.until;

import java.io.Serializable;

public class JsonUntil<E> implements Serializable {
    private Integer state;//状态码
    private String message;
    private E data;//枚举类型，用来传数据
    public JsonUntil()
    {

    }
    public JsonUntil(Integer state) {
        this.state = state;
    }

    public JsonUntil(Integer state, E data) {
        super();
        this.state = state;
        this.data = data;
    }

    //异常捕获
    public JsonUntil(Throwable throwable)
    {
        this.message=throwable.getMessage();
    }
    public JsonUntil(Integer state, String message) {
        this.state = state;
        this.message = message;
    }


    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public E getData() {
        return data;
    }

    public void setData(E data) {
        this.data = data;
    }
}
