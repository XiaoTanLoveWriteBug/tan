package com.tan.webstore.controller;

import com.tan.webstore.POJO.Address;
import com.tan.webstore.service.impl.AdressServiceImpl;
import com.tan.webstore.until.JsonUntil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
public class AddressContorller extends BaseController {
@Autowired
    AdressServiceImpl adressService;


@RequestMapping("/AddNewAdress")
    public JsonUntil<Void> AddNewAdress(HttpSession session, Address address)
{
Integer uid=getuidFromSession(session);
String username=getUsernameFromSession(session);
adressService.AddNewAdress(uid,username,address);

return new  JsonUntil<>(Ok);

}

    @GetMapping({"/getAddress"})
    public JsonUntil<List<Address>> getByUid(HttpSession session) {
        Integer uid = getuidFromSession(session);
        List<Address> data =adressService.getbyid(uid);
        return new JsonUntil<>(Ok, data);
    }

    @RequestMapping("/{aid}/set_default")
    public JsonUntil<Void> setDefault(@PathVariable("aid") Integer aid, HttpSession session) {
        Integer uid = getuidFromSession(session);
        String username = getUsernameFromSession(session);
        adressService.setDefault(aid, uid, username);
        return new JsonUntil<>(Ok);
    }

    @RequestMapping("/{aid}/delete")
    public JsonUntil<Void> delete(@PathVariable("aid") Integer aid, HttpSession session) {
        Integer uid = getuidFromSession(session);
        String username = getUsernameFromSession(session);
        adressService.delete(aid, uid, username);
        return new JsonUntil<Void>(Ok);
    }



}
