contorller如何请求数据呢？
利用json,我们创建一个类来封装它(需要继承)
包括三部分：
    数据
    状态码
    描述信息
    
    设计请求
    依据当前的业务功能模块：
    请求路径user/reg
    请求参数 user user
    返回结果：josnreslut<void>
    相应 类型：数据比较敏感的用post,其他的用get
        
  处理请求      