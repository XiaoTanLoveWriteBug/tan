package com.tan.webstore.service;

import com.tan.webstore.POJO.User;
import org.apache.ibatis.annotations.Param;

public interface IUserService {
//    注册
    void reg(User user);
//登录,成功后将用户形式展示给后面页面，可以将信息保存在Cookies中，没有信息则返回null值
    User login(String username,String PASSWORD);



    void UpdatePassword(int uid,String username,String OldPassword,String NewPassword);
//更新用户数据操作
    User getByUid(Integer uid);
    void changinfo(User user,String username,Integer id);
    void updateavatar( Integer uid,String avatar, String username);



}

