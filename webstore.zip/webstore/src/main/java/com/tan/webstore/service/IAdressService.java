package com.tan.webstore.service;

import com.tan.webstore.POJO.Address;

import java.util.List;

public interface IAdressService {
    //增加收货地址
void AddNewAdress(Integer uid,String username,Address address);
List<Address> getbyid(Integer uid);
    void setDefault(Integer aid, Integer uid, String username);
   //删除收货地址

    void delete(Integer aid, Integer uid, String username);

//根据收货地址数据的id，查询收货地址详情
    Address getByAid(Integer aid, Integer uid);

}
