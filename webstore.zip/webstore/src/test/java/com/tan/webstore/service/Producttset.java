package com.tan.webstore.service;

import com.tan.webstore.POJO.Product;
import com.tan.webstore.service.impl.ProductServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@SpringBootTest
@RunWith(SpringRunner.class)
public class Producttset {
    @Autowired
    ProductServiceImpl productService;

    @Test
    public void findHotList() {
        List<Product> list= productService.findHotList();
        System.out.println(list);
        System.out.println(productService.findById(10000001));
    }
}
