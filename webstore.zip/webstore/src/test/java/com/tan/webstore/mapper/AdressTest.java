package com.tan.webstore.mapper;


import com.tan.webstore.POJO.Address;
import com.tan.webstore.POJO.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.List;

//标注这是一个测试类，不会被项目打包发送
@SpringBootTest
//RunWith 表示启动这个单元测试类，参数是固定的
@RunWith(SpringRunner.class)
public class AdressTest {

    @Autowired

//    这里报错的原因，接口不能创造bean(底层是动态代理)
private AdressMapper adressMapper;
//测试新增地址
    @Test
    public void name() {
        Address address=new Address();
        address.setUid(76);
        address.setPhone("5254");
        address.setName("5265");
        adressMapper.insertAdress(address);

    }

    @Test
    public void countByUid() {
        System.out.println(adressMapper.countByUid(76));
    }

    @Test
    public void FindAdressByUID() {
        List<Address> list=adressMapper.FindAdressByUID(76);
        System.out.println(list);
    }


    @Test
    public void updateNonDefaultByUid() {
        Integer uid = 76;
        Integer rows = adressMapper.updateNonDefaultByUid(uid);
        System.out.println("rows=" + rows);
    }

    @Test
    public void updateDefaultByAid() {
        Integer aid = 8;
        String modifiedUser = "管理员";
        Date modifiedTime = new Date();
        Integer rows = adressMapper.updateDefaultByAid(aid, modifiedUser, modifiedTime);
        System.out.println("rows=" + rows);
    }

    @Test
    public void findByAid() {
        Integer aid = 8;
        Address result = adressMapper.findByAid(aid);
        System.out.println(result);
    }

    @Test
    public void deleteByAid() {
        Integer aid = 4;
        Integer rows = adressMapper.deleteByAid(aid);
        System.out.println("rows=" + rows);
    }

    @Test
    public void findLastModified() {
        Integer uid = 30;
        Address result = adressMapper.findLastModified(uid);
        System.out.println(result);
    }

}

