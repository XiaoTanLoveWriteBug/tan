package com.tan.webstore.service;

import com.tan.webstore.POJO.User;
import com.tan.webstore.mapper.Usermapper;
import com.tan.webstore.service.ex.ServiceException;
import com.tan.webstore.service.impl.UserServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
@RunWith(SpringRunner.class)
public class ServiceTest {
@Autowired
    UserServiceImpl userService;

    @Test
    public void addusername() {
//        测试我们能否抛出异常
        User user=new User();

        try {

            user.setUsername("7k79");
            user.setPASSWORD("7k79");
            userService.reg(user);
            System.out.println("添加成功");
            System.out.println(user.getSalt());
            System.out.println(user.getPASSWORD());
            System.out.println(userService.getMD5PASSWORD("7k79", user.getSalt()));

        }
        catch (ServiceException e)
        {
            System.out.println(e.getClass());
            System.out.println(e.getMessage());
        }

    }

//    账号登录密码单元测试
    @Test
    public void login() {
        User user;

 user= userService.login("7k79", "7k79");


        System.out.println(user);
    }
//md5单元测试
    @Test
    public void md5() {

        System.out.println(userService.getMD5PASSWORD("100", "553B99BE-7E46-41F3-B9C7-1ADCBFB3A173"));


    }

//修改密码单元测试
    @Test
    public void UpdatePassword() {
userService.UpdatePassword(84,"1111","250","1111");

    }
    //修改信息单元测试

    @Test
    public void updateINFO() {
        User user=new User();
        user.setPhone("155");
        user.setEmail("155");
        user.setGender(0);

    userService.changinfo(user,"adad",84);
    }

    @Test
    public void getbyid() {

        System.out.println(userService.getByUid(84));
    }
    
    //头像插入

    @Test
    public void updateavatar() {
        userService.updateavatar(76,"dad/dada/dad","就是这么狂");


    }
}
