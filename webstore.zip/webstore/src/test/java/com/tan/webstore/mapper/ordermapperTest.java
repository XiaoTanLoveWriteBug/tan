package com.tan.webstore.mapper;


import com.tan.webstore.POJO.Order;
import com.tan.webstore.POJO.OrderItem;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

//标注这是一个测试类，不会被项目打包发送
@SpringBootTest
@RunWith(SpringRunner.class)
//RunWith 表示启动这个单元测试类，参数是固定的
public class ordermapperTest {

    @Autowired
    private OrderMapper orderMapper;



    @Test
    public void addorder() {
        Order order = new Order();
        order.setUid(76);
        order.setRecvName("dadad飞");
        order.setRecvPhone("155464854545");
        orderMapper.AddOrder(order);

//
    }

    @Test
    public void addorderItem()  {
        OrderItem orderItem=new OrderItem();
        orderItem.setOid(1);
        orderItem.setPid(10000002);
        orderItem.setTitle("dadadada");
        orderMapper.AddOrderItem(orderItem);
    }

    @Test
    public void selectoid() {
    Order order=new Order();
    order.setUid(76);
    //long total=476388;
  //  order.setTotalPrice(null);
        System.out.println(orderMapper.selectoid(order));

    }
}

