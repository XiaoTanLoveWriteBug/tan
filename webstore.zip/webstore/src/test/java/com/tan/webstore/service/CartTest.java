package com.tan.webstore.service;

import com.tan.webstore.POJO.User;
import com.tan.webstore.mapper.CartMapper;
import com.tan.webstore.service.ex.ServiceException;
import com.tan.webstore.service.impl.CarServiceIml;
import com.tan.webstore.service.impl.UserServiceImpl;
import com.tan.webstore.vo.CartVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@SpringBootTest
@RunWith(SpringRunner.class)
public class CartTest {
@Autowired
    CarServiceIml serviceIml;

    @Test
    public void addtoCart() {
        serviceIml.addtoCart(76,10000004,12,"张三");
    }

    @Test
    public void findVOByCids() {
        Integer[] cids = {1, 2, 6, 7, 8, 9, 10};
        Integer uid = 76;
        List<CartVO> list = serviceIml.getVOByCids(uid, cids);
        System.out.println("count=" + list.size());
        for (CartVO item : list) {
            System.out.println(item);
        }

    }
}
