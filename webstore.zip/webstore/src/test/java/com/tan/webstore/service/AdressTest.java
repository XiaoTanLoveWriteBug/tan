package com.tan.webstore.service;

import com.tan.webstore.POJO.Address;
import com.tan.webstore.POJO.User;
import com.tan.webstore.service.ex.ServiceException;
import com.tan.webstore.service.impl.AdressServiceImpl;
import com.tan.webstore.service.impl.UserServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
@RunWith(SpringRunner.class)
public class AdressTest {
@Autowired
    AdressServiceImpl adressService;

    @Test
    public void AddNewAdress() {
        Address adress=new Address();
        adress.setPhone("1233156");
        adress.setName("dadad");
        adressService.AddNewAdress(74,"dada",adress);

    }

    @Test
    public void delete() {
        adressService.delete(12,76,"13");
    }
}
