package com.tan.webstore.mapper;


import com.tan.webstore.POJO.Address;
import com.tan.webstore.POJO.District;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.List;

//标注这是一个测试类，不会被项目打包发送
@SpringBootTest
//RunWith 表示启动这个单元测试类，参数是固定的
@RunWith(SpringRunner.class)
public class DistrictMapper2 {



    @Autowired
    private DistrictMapper districtMapper;

    @Test
    public void findByParent() {
        String parent = "110100";
        List<District> list = districtMapper.findByParent(parent);
        System.out.println("count=" + list.size());
        for (District district : list) {
            System.out.println(district);
        }
    }

    @Test
    public void findNameByCode() {

        System.out.println(districtMapper.findNameByCode("610000"));
    }




}
