package com.tan.webstore.service;

import com.tan.webstore.POJO.District;
import com.tan.webstore.POJO.User;
import com.tan.webstore.service.ex.ServiceException;
import com.tan.webstore.service.impl.IDistrictServiceImp;
import com.tan.webstore.service.impl.UserServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@SpringBootTest
@RunWith(SpringRunner.class)
public class IDistrictServiceTest {
    @Autowired
    IDistrictServiceImp iDistrictServiceImp;

    @Test
    public void addusername() {
//        测试我们能否抛出异常
        List<District> list=iDistrictServiceImp.getByParent("110100");
        for (District d:list)
        {
            System.out.println(list);
        }

    }
}