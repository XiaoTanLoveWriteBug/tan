package com.tan.webstore.service;

import com.tan.webstore.service.impl.CarServiceIml;
import com.tan.webstore.service.impl.OrderServiceImpl;
import com.tan.webstore.vo.CartVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@SpringBootTest
@RunWith(SpringRunner.class)
public class OrderTest {
@Autowired
OrderServiceImpl orderService;

    @Test
    public void AddOerder() {
        Integer[] cids={3,4,5,6};
        orderService.AddOerder(14,76,"adjaid",cids);
    }
}

