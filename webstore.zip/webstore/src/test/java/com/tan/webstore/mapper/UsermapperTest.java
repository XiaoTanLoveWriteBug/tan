package com.tan.webstore.mapper;


import com.tan.webstore.POJO.User;
import com.tan.webstore.service.impl.UserServiceImpl;
import org.apache.ibatis.annotations.Mapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

//标注这是一个测试类，不会被项目打包发送
@SpringBootTest
//RunWith 表示启动这个单元测试类，参数是固定的
@RunWith(SpringRunner.class)
public class UsermapperTest {

    @Autowired

//    这里报错的原因，接口不能创造bean(底层是动态代理)
private Usermapper usermapper;
    @Test
    public void addUserTest() {
User user=new User();
user.setUsername("j0j");
user.setPASSWORD("5555");

usermapper.addUser(user);
        System.out.println("插入成功");
    }

    @Test
    public void quuryid() {
        System.out.println(usermapper.findByUid(73));
    }

//测试修改密码


    @Test
    public void uppassword() {
        usermapper.UpdatePassword(84,"1111","起飞",new Date());
    }


    @Test
    public void updateInforByuid() {
        User user = new User();user.setUid(84);
        user.setPhone( "15511110000");user.setEmail( "test002@qq.com" );
        user.setGender(1);
        user.setModifiedUser(user.getUsername());
      usermapper.updateInforByuid(user);

    }


    @Test
    public void updateavatarByuid() {
  usermapper.updateavatarByuid(76,"dadad","dadad",new Date());

    }




}
